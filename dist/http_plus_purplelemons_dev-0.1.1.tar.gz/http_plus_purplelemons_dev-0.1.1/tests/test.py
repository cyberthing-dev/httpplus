
def __call__():
    print("well hello there")
