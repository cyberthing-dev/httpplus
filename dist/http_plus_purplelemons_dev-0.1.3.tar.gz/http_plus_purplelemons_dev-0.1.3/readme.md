
# HTTPPlus
hi welcome to http plus. It's a high-level, dynamic HTTP server for Python. Quickly deploy simple servers, or customize complex, 
high-performance ones.

## Version
Pre-release version 0.1.3

(go check the [changelog](./changelog.md) for more info on versions plz i worked hard on it thx)

# Future plans
- [ ] HTTPS
- [ ] CLI
- [ ] Documentation
- [ ] GUI Console
- [ ] Config file support?

[//]: # (TODO: add more stuff here)
[//]: # (TODO: Automate version number update with github actions)
